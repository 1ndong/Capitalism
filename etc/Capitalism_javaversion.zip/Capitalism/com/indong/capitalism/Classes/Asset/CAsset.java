package com.indong.capitalism.Classes.Asset;

public class CAsset {

}
