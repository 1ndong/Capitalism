package com.indong.capitalism.Classes.Government;

import com.indong.capitalism.Classes.CCountry;

public class CGNationalTaxService extends CGovernment {

    //todo 세금율 조사 각각 인터페이스 만들어서 조정할수있도록
    //각각 인터페이스 만들어서 낼사람들 등록

    public CGNationalTaxService(CCountry country) {
        super(country);
    }
}
