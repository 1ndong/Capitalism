package com.indong.capitalism.Classes.Stuff;

public class CStuff {
    private String name;
    private String price;

    public CStuff(String name , String price)
    {
        this.name = name;
        this.price = price;
    }

    public String getName()
    {
        return name;
    }

    public String getPrice()
    {
        return price;
    }
}
