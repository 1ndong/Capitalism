package com.indong.capitalism.DataStructure;

public class DHistory {
	//memento pattern
	protected DTime time;
	
	public DHistory(DTime time)
	{
		
	}
}
