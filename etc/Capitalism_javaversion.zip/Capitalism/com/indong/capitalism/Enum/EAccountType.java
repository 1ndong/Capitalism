package com.indong.capitalism.Enum;

public enum EAccountType {
	Deposit,Loan,Saving,NationalAccount
}
