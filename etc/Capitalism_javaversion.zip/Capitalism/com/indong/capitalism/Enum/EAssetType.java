package com.indong.capitalism.Enum;

public enum EAssetType {
	Risky , Riskless
}
