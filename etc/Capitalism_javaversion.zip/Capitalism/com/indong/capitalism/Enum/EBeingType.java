package com.indong.capitalism.Enum;

public enum EBeingType {
	Personal,Company
}
