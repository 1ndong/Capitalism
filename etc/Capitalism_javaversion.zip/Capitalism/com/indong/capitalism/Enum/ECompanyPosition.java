package com.indong.capitalism.Enum;

public enum ECompanyPosition
{
	Clerk , SeniorClerk , AssistantManager , Manager , DeputyGeneralManager , GeneralManager
}