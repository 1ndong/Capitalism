package com.indong.capitalism.Enum;

public enum ECurrency {
	Won,Dollar,Euro
}
