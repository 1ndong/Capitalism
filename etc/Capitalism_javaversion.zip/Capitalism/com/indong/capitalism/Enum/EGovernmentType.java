package com.indong.capitalism.Enum;

public enum EGovernmentType {
	HealthAndWelfare, TradeIndustryAndEnergy
}
