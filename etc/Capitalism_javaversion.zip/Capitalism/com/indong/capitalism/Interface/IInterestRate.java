package com.indong.capitalism.Interface;

public interface IInterestRate {
	void interestChange(float newinterestrate);
}
