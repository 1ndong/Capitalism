package com.indong.capitalism.Interface;

import com.indong.capitalism.DataStructure.DTime;

public interface ITime {
	void dayChange(DTime newTime);
}
