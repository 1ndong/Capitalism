package com.indong.capitalism.Interface;

public interface ITimeKeeper {
	void addTimeSlave(ITime newslave);
	void updateTime();
}
