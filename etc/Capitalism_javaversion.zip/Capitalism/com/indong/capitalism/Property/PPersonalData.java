package com.indong.capitalism.Property;

import com.indong.capitalism.DataStructure.DTime;

public class PPersonalData extends PBasicData {

	public PPersonalData(DTime birth, String name) {
		// TODO Auto-generated constructor stub
		super(birth, name);
	}
	
}
