package com.indong.capitalism.UI.CustomPanel.ControlPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SubmitClickListener implements ActionListener {

    private ControlPanel cp;

    public SubmitClickListener(ControlPanel cp)
    {
        this.cp = cp;
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

    }
}
