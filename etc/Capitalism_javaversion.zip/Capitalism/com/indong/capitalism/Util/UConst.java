package com.indong.capitalism.Util;

public class UConst {
    public static final String StrDelim = "[!DELIM!]";
}
